package cs5530;

public class ReserveObj {
	public String vin;
	public int cost;
	public int start;
	public int end;
	public String date;
}
